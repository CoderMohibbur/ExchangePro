<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-xl dark:text-white font-semibold">View Bank Details</h1>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="container mx-auto px-4 py-4">
                <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800 p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-semibold text-gray-800 dark:text-gray-200">Bank Details</h2>
                        <a href="<?php echo e(route('banks.index')); ?>"
                            class="px-4 py-2 bg-gray-500 text-white font-semibold rounded-md hover:bg-gray-600 dark:bg-gray-600 dark:hover:bg-gray-700 transition">
                            Back to Bank List
                        </a>
                    </div>

                    <!-- Bank Details Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Bank Name -->
                        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-md">
                            <h3 class="font-semibold text-gray-700 dark:text-gray-200">Bank Name</h3>
                            <p class="text-gray-600 dark:text-gray-400"><?php echo e($bank->name); ?></p>
                        </div>

                        <!-- Beneficiary Name -->
                        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-md">
                            <h3 class="font-semibold text-gray-700 dark:text-gray-200">Beneficiary Name</h3>
                            <p class="text-gray-600 dark:text-gray-400"><?php echo e($bank->beneficiary_name); ?></p>
                        </div>

                        <!-- Account Number -->
                        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-md">
                            <h3 class="font-semibold text-gray-700 dark:text-gray-200">Account Number</h3>
                            <p class="text-gray-600 dark:text-gray-400"><?php echo e($bank->account_number); ?></p>
                        </div>


                        <!-- Net Total Balance (All-Time) -->
                        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-md">
                            <h3 class="font-semibold text-gray-700 dark:text-gray-200">Net Total Balance (All-Time)</h3>
                            <p class="text-gray-600 dark:text-gray-400"><?php echo e(number_format($netTotalBalance, 2)); ?> BDT</p>
                        </div>
                        <!-- Total Debits for Current Month -->
                        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-md">
                            <h3 class="font-semibold text-gray-700 dark:text-gray-200">Bank To Bank Month</h3>
                            <p class="text-gray-600 dark:text-gray-400"><?php echo e(number_format($bankToBankMonth, 2)); ?> BDT</p>
                        </div>

                        <!-- Total Credits for Current Month -->
                        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-md">
                            <h3 class="font-semibold text-gray-700 dark:text-gray-200">NPSB This Month</h3>
                            <p class="text-gray-600 dark:text-gray-400"><?php echo e(number_format($npsbThisMonth, 2)); ?> BDT</p>
                        </div>

                        <!-- Total Debits for Current Year -->
                        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-md">
                            <h3 class="font-semibold text-gray-700 dark:text-gray-200">Bank To Bank Today</h3>
                            <p class="text-gray-600 dark:text-gray-400"><?php echo e(number_format($bankToBankToday, 2)); ?> BDT</p>
                        </div>

                        <!-- Total Credits for Current Year -->
                        <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-md">
                            <h3 class="font-semibold text-gray-700 dark:text-gray-200">NPSB Today</h3>
                            <p class="text-gray-600 dark:text-gray-400"><?php echo e(number_format($npsbThisMonth, 2)); ?> BDT</p>
                        </div>
                    </div>

                    <!-- Transactions Table -->
                    <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800 mt-10 border-2">
                        <div class="flex justify-between items-center p-4">
                            <!-- Search Form -->
                            <form action="<?php echo e(route('bank_transactions.index')); ?>" method="GET" class="flex space-x-2">
                                <input type="text" name="search" placeholder="Search by bank or transaction type"
                                    value="<?php echo e(request('search')); ?>"
                                    class="w-full px-4 py-2 border rounded-md dark:bg-gray-700 dark:text-white dark:border-gray-600" />
                                <button type="submit"
                                    class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 transition">
                                    Search
                                </button>
                            </form>
                            <a href="<?php echo e(route('bank_transactions.create')); ?>"
                                class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 transition">
                                Add New Transaction
                            </a>
                        </div>

                        <!-- Transactions Table -->
                        <div class="overflow-x-auto">
                            <table
                                class="w-full min-w-max table-auto bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200">
                                <thead class="bg-gray-100 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-4 py-2 text-left font-semibold">Bank Name</th>
                                        <th class="px-4 py-2 text-left font-semibold">Transaction Type</th>
                                        <th class="px-4 py-2 text-left font-semibold">Amount</th>
                                        <th class="px-4 py-2 text-left font-semibold">Transaction ID</th>
                                        <th class="px-4 py-2 text-center font-semibold">Date</th>
                                        <th class="px-4 py-2 text-center font-semibold">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr class="border-b border-gray-200 dark:border-gray-700">
                                            <td class="px-4 py-3"><?php echo e($transaction->bank->name); ?></td>
                                            <td class="px-4 py-3"><?php echo e(ucfirst($transaction->transaction_type)); ?>

                                            </td>
                                            <td class="px-4 py-3"><?php echo e(number_format($transaction->amount, 2)); ?> BDT
                                            </td>
                                            <td class="px-4 py-3"><?php echo e($transaction->reference ?? 'N/A'); ?></td>
                                            <td class="px-4 py-3 text-center">
                                                <?php echo e($transaction->transaction_date); ?></td>
                                            <td class="px-4 py-3 flex space-x-2 justify-center">
                                                <a href="<?php echo e(route('bank_transactions.edit', $transaction)); ?>"
                                                    class="px-3 py-1 text-sm font-semibold text-yellow-600 border border-yellow-600 rounded hover:bg-yellow-600 hover:text-white dark:text-yellow-400 dark:border-yellow-400 dark:hover:text-white transition duration-200">
                                                    Edit
                                                </a>
                                                <form action="<?php echo e(route('bank_transactions.destroy', $transaction)); ?>"
                                                    method="POST" onsubmit="return confirm('Are you sure?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                        class="px-3 py-1 text-sm font-semibold text-red-600 border border-red-600 rounded hover:bg-red-600 hover:text-white dark:text-white dark:border-red-400 dark:hover:bg-red-500 transition duration-200">
                                                        Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6"
                                                class="px-4 py-3 text-center text-gray-500 dark:text-gray-400">
                                                No transactions found.
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination and Results Info -->
                        <div class="bg-gray-50 dark:bg-gray-900 p-4 rounded-b-lg">
                            <div class="flex items-center justify-between">
                                <p class="text-sm text-gray-600 dark:text-gray-400">
                                    Showing <span class="font-semibold"><?php echo e($transactions->firstItem()); ?></span> to
                                    <span class="font-semibold"><?php echo e($transactions->lastItem()); ?></span> of <span
                                        class="font-semibold"><?php echo e($transactions->total()); ?></span> results
                                </p>
                                <div class="flex">
                                    <?php echo e($transactions->links()); ?> <!-- Pagination Links -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Development\Laravel\ExchangePro\resources\views/banks/show.blade.php ENDPATH**/ ?>