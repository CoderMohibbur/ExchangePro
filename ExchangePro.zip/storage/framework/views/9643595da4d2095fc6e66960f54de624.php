<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-xl dark:text-white font-semibold">User Details for <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h1>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="container mx-auto px-4 py-4">
                <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800 p-6">
                    <form method="GET">
                        <div class="grid grid-cols-2 gap-4">
                            <!-- First Name -->
                            <div>
                                <label for="first_name" class="block text-gray-700 dark:text-gray-300">First Name:</label>
                                <input type="text" id="first_name" value="<?php echo e($user->first_name); ?>" class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" disabled>
                            </div>

                            <!-- Last Name -->
                            <div>
                                <label for="last_name" class="block text-gray-700 dark:text-gray-300">Last Name:</label>
                                <input type="text" id="last_name" value="<?php echo e($user->last_name); ?>" class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" disabled>
                            </div>

                            <!-- Email -->
                            <div>
                                <label for="email" class="block text-gray-700 dark:text-gray-300">Email:</label>
                                <input type="email" id="email" value="<?php echo e($user->email); ?>" class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" disabled>
                            </div>

                            <!-- Phone Number -->
                            <div>
                                <label for="phone_number" class="block text-gray-700 dark:text-gray-300">Phone Number:</label>
                                <input type="text" id="phone_number" value="<?php echo e($user->phone_number ?? 'N/A'); ?>" class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" disabled>
                            </div>

                            <!-- Role -->
                            <div>
                                <label for="role_id" class="block text-gray-700 dark:text-gray-300">Role:</label>
                                <input type="text" id="role_id" value="<?php echo e($user->role->name ?? 'N/A'); ?>" class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" disabled>
                            </div>

                            <!-- User Type -->
                            <div>
                                <label for="user_type_id" class="block text-gray-700 dark:text-gray-300">User Type:</label>
                                <input type="text" id="user_type_id" value="<?php echo e($user->userType->name ?? 'N/A'); ?>" class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" disabled>
                            </div>

                            <!-- Username -->
                            <div>
                                <label for="username" class="block text-gray-700 dark:text-gray-300">Username:</label>
                                <input type="text" id="username" value="<?php echo e($user->username ?? 'N/A'); ?>" class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" disabled>
                            </div>

                            <!-- Active Status -->
                            <div>
                                <label for="active_status" class="block text-gray-700 dark:text-gray-300">Status:</label>
                                <input type="text" id="active_status" value="<?php echo e($user->active_status == 1 ? 'Active' : 'Inactive'); ?>" class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" disabled>
                            </div>

                            <!-- Allow Login -->
                            <div>
                                <label for="allow_login" class="block text-gray-700 dark:text-gray-300">Allow Login?</label>
                                <input type="text" id="allow_login" value="<?php echo e($user->allow_login ? 'Yes' : 'No'); ?>" class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" disabled>
                            </div>
                        </div>
                        <!-- Cancel Button -->
                        <div class="mt-4">
                            <a href="<?php echo e(route('users.index')); ?>" class="px-4 py-2 bg-gray-500 text-white font-semibold rounded-md hover:bg-gray-600 transition duration-200">Back to Users List</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Development\Laravel\ExchangePro\resources\views/users/show.blade.php ENDPATH**/ ?>