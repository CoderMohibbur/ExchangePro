<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between">
        <h1 class="text-xl dark:text-white font-semibold">Manage Banks</h1>
        <h1 class="text-xl dark:text-white font-semibold">Total Bank Blance: <?php echo e(number_format($banks->sum('balance'), 2)); ?></h1>
    </div>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="container mx-auto px-4 py-4">
                <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800">
                    <?php if (isset($component)) { $__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast-success','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast-success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06)): ?>
<?php $attributes = $__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06; ?>
<?php unset($__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06)): ?>
<?php $component = $__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06; ?>
<?php unset($__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa)): ?>
<?php $attributes = $__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa; ?>
<?php unset($__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa)): ?>
<?php $component = $__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa; ?>
<?php unset($__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal56620e3087b695c518f488efcc0f195d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56620e3087b695c518f488efcc0f195d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast-warning','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56620e3087b695c518f488efcc0f195d)): ?>
<?php $attributes = $__attributesOriginal56620e3087b695c518f488efcc0f195d; ?>
<?php unset($__attributesOriginal56620e3087b695c518f488efcc0f195d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56620e3087b695c518f488efcc0f195d)): ?>
<?php $component = $__componentOriginal56620e3087b695c518f488efcc0f195d; ?>
<?php unset($__componentOriginal56620e3087b695c518f488efcc0f195d); ?>
<?php endif; ?>
                    <div class="flex justify-between p-4">
                        <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-200">Banks</h2>
                        <a href="<?php echo e(route('banks.create')); ?>"
                            class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 transition">
                            Add New Bank
                        </a>
                    </div>
                    <div class="overflow-x-auto">
                        <table
                            class="w-full min-w-max table-auto bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200">
                            <thead class="bg-gray-100 dark:bg-gray-700">
                                <tr>
                                    <th class="px-4 py-2 text-left font-semibold">Bank Name</th>
                                    <th class="px-4 py-2 text-left font-semibold">Beneficiary Name</th>
                                    <th class="px-4 py-2 text-left font-semibold">Account Number</th>
                                    
                                    <th class="px-4 py-2 text-center font-semibold">Total Balance (BDT)</th>
                                    <th class="px-4 py-2 text-center font-semibold">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border-b border-gray-200 dark:border-gray-700">
                                        <td class="px-4 py-3 flex ">
                                            <img class="<?php echo e($bank->logo ? 'max-w-6 rounded-full' : 'max-w-6 rounded-full p-1 bg-white'); ?>"
                                            src="<?php echo e($bank->logo ? asset('storage/' . $bank->logo) : asset('images/bank-mini.png')); ?>"
                                            alt="Bank Logo">
                                            <a href="<?php echo e(route('banks.show', $bank->id)); ?>"
                                                class="text-blue-500 ml-2 hover:underline">
                                                <?php echo e($bank->name); ?>

                                                <!-- SVG Icon after bank name -->
                                            </a>
                                            
                                        </td>
                                        <td class="px-4 py-3"><?php echo e($bank->beneficiary_name); ?></td>
                                        <td class="px-4 py-3"><?php echo e($bank->account_number); ?></td>
                                        
                                        <td class="px-4 py-3 text-center"><?php echo e(number_format($bank->balance, 2)); ?></td>
                                        <td class="px-4 py-3 flex space-x-2 justify-center">
                                            <a href="<?php echo e(route('banks.edit', $bank->id)); ?>"
                                                class="px-3 py-1 text-sm font-semibold text-yellow-600 border border-yellow-600 rounded hover:bg-yellow-600 hover:text-white transition duration-200">
                                                Edit
                                            </a>
                                            <form action="<?php echo e(route('banks.destroy', $bank->id)); ?>" method="POST"
                                                onsubmit="return confirm('Are you sure you want to delete this bank?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="px-3 py-1 text-sm font-semibold text-red-600 border border-red-600 rounded hover:bg-red-600 hover:text-white transition duration-200">
                                                    Delete
                                                </button>
                                            </form>
                                            <a href="<?php echo e(route('banks.withdrawForm', $bank->id)); ?>"
                                                class="px-3 py-1 text-sm font-semibold text-blue-500 border border-blue-500 rounded hover:bg-blue-500 hover:text-white transition duration-200">
                                                Withdraw
                                            </a>
                                            <a href="<?php echo e(route('banks.depositForm', $bank->id)); ?>"
                                                class="px-3 py-1 text-sm font-semibold text-green-500 border border-green-500 rounded hover:bg-green-500 hover:text-white transition duration-200">
                                                Deposit
                                            </a>

                                            <!-- Copy Info Button -->
                                            <button type="button"
                                                class="px-3 py-1 text-sm font-semibold text-blue-500 border border-blue-500 rounded hover:bg-blue-500 hover:text-white transition duration-200"
                                                onclick="copyBankInfo('<?php echo e($bank->name); ?>', '<?php echo e($bank->beneficiary_name); ?>', '<?php echo e($bank->account_number); ?>', '<?php echo e($bank->account_type); ?>', '<?php echo e($bank->routing); ?>', '<?php echo e($bank->bank_address); ?>')">
                                                Copy Info
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8"
                                            class="px-4 py-3 text-center text-gray-500 dark:text-gray-400">
                                            No banks found.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript for Copying Info -->
    <script>
        function copyBankInfo(name, beneficiaryName, accountNumber, accountType, routing, bankAddress) {
            // Create the text to be copied
            const info =
                `Bank name:\n${name}\n\nBank address:\n${bankAddress}\n\nRouting (ABA):\n${routing}\n\nAccount number:\n${accountNumber}\n\nAccount type:\n${accountType}\n\nBeneficiary name:\n${beneficiaryName}`;

            // Create a temporary textarea to copy the text
            const textarea = document.createElement('textarea');
            textarea.value = info;
            document.body.appendChild(textarea);

            // Select and copy the text
            textarea.select();
            document.execCommand('copy');

            // Remove the temporary textarea
            document.body.removeChild(textarea);

            // Alert the user
            alert('Bank information copied to clipboard!');
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Development\Laravel\ExchangePro\resources\views/banks/index.blade.php ENDPATH**/ ?>