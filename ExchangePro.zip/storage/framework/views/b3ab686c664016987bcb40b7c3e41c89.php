<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-xl dark:text-white font-semibold">All Users</h1>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="container mx-auto px-4 py-4">
                <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800">
                    <?php if (isset($component)) { $__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast-success','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast-success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06)): ?>
<?php $attributes = $__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06; ?>
<?php unset($__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06)): ?>
<?php $component = $__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06; ?>
<?php unset($__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa)): ?>
<?php $attributes = $__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa; ?>
<?php unset($__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa)): ?>
<?php $component = $__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa; ?>
<?php unset($__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal56620e3087b695c518f488efcc0f195d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56620e3087b695c518f488efcc0f195d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast-warning','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56620e3087b695c518f488efcc0f195d)): ?>
<?php $attributes = $__attributesOriginal56620e3087b695c518f488efcc0f195d; ?>
<?php unset($__attributesOriginal56620e3087b695c518f488efcc0f195d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56620e3087b695c518f488efcc0f195d)): ?>
<?php $component = $__componentOriginal56620e3087b695c518f488efcc0f195d; ?>
<?php unset($__componentOriginal56620e3087b695c518f488efcc0f195d); ?>
<?php endif; ?>
                    <!-- Search Form -->
                    <div class="flex justify-between items-center p-4">
                        <form action="<?php echo e(route('users.index')); ?>" method="GET" class="flex space-x-2">
                            <input type="text" name="search" placeholder="Search by name or email"
                                   value="<?php echo e(request('search')); ?>"
                                   class="w-full px-4 py-2 border rounded-md dark:bg-gray-700 dark:text-white dark:border-gray-600" />
                            <button type="submit" class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 transition">
                                Search
                            </button>
                        </form>
                        <a href="<?php echo e(route('users.create')); ?>"
                           class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 transition">
                           Add New User
                        </a>
                    </div>

                    <!-- Users Table -->
                    <div class="overflow-x-auto">
                        <table class="w-full min-w-max table-auto bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200">
                            <thead class="bg-gray-100 dark:bg-gray-700">
                                <tr>
                                    <th class="px-4 py-2 text-left font-semibold">ID</th>
                                    <th class="px-4 py-2 text-left font-semibold">Full Name</th>
                                    <th class="px-4 py-2 text-left font-semibold">Email</th>
                                    <th class="px-4 py-2 text-left font-semibold">Role</th>
                                    <th class="px-4 py-2 text-left font-semibold">Status</th>
                                    <th class="px-4 py-2 text-left font-semibold">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border-b border-gray-200 dark:border-gray-700">
                                        <td class="px-4 py-3"><?php echo e($user->id); ?></td>
                                        <td class="px-4 py-3"><?php echo e($user->full_name); ?></td>
                                        <td class="px-4 py-3"><?php echo e($user->email); ?></td>
                                        <td class="px-4 py-3"><?php echo e($user->role->name ?? 'N/A'); ?></td>
                                        <td class="px-4 py-3">
                                            <span class="px-2 py-1 rounded-full text-sm font-medium
                                                <?php echo e($user->active_status ? 'bg-green-200 text-green-700' : 'bg-red-200 text-red-700'); ?>">
                                                <?php echo e($user->active_status ? 'Active' : 'Inactive'); ?>

                                            </span>
                                        </td>
                                        <td class="px-4 py-3">
                                            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="px-4 py-1 text-sm font-semibold text-blue-500 border border-blue-500 rounded hover:bg-blue-500 hover:text-white transition duration-200">
                                                Edit
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="px-4 py-3 text-center text-gray-500 dark:text-gray-400">
                                            No users found.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="bg-gray-50 dark:bg-gray-900 p-4 rounded-b-lg">
                        <div class="flex items-center justify-between">
                            <p class="text-sm text-gray-600 dark:text-gray-400">
                                Showing <span class="font-semibold"><?php echo e($users->firstItem()); ?></span> to <span class="font-semibold"><?php echo e($users->lastItem()); ?></span> of <span class="font-semibold"><?php echo e($users->total()); ?></span> results
                            </p>
                            <div class="flex">
                                <?php echo e($users->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Development\Laravel\ExchangePro\resources\views/users/index.blade.php ENDPATH**/ ?>