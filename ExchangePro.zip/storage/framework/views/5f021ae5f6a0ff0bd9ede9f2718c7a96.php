<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-xl dark:text-white font-semibold">Edit Currency</h1>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="container mx-auto px-4 py-4">
                <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800 p-6">
                    <form action="<?php echo e(route('currencies.update', $currency)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="grid gap-6 grid-cols-2">
                            <!-- Name -->
                            <div>
                                <label class="block text-gray-700 dark:text-gray-300">Currency Name</label>
                                <input type="text" name="name" value="<?php echo e(old('name', $currency->name)); ?>"
                                    class="w-full mt-1 border rounded p-2 dark:bg-gray-700 dark:text-gray-300" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Code -->
                            <div>
                                <label class="block text-gray-700 dark:text-gray-300">Currency Code</label>
                                <input type="text" name="code" value="<?php echo e(old('code', $currency->code)); ?>"
                                    class="w-full mt-1 border rounded p-2 dark:bg-gray-700 dark:text-gray-300" required>
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Exchange Rate -->
                            <div>
                                <label class="block text-gray-700 dark:text-gray-300">Exchange Rate</label>
                                <input type="number" name="exchange_rate" step="0.0001" value="<?php echo e(old('exchange_rate', $currency->exchange_rate)); ?>"
                                    class="w-full mt-1 border rounded p-2 dark:bg-gray-700 dark:text-gray-300">
                                <?php $__errorArgs = ['exchange_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Currency Symbol -->
                            <div>
                                <label class="block text-gray-700 dark:text-gray-300">Currency Symbol</label>
                                <input type="text" name="cur_sym" value="<?php echo e(old('cur_sym', $currency->cur_sym)); ?>"
                                    class="w-full mt-1 border rounded p-2 dark:bg-gray-700 dark:text-gray-300">
                                <?php $__errorArgs = ['cur_sym'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Reserve Amount (disabled) -->
                            <div class="hidden">
                                <label class="block text-gray-700 dark:text-gray-300">Reserve Amount</label>
                                <input type="number" name="reserve" step="0.01" value="<?php echo e(old('reserve', $currency->reserve)); ?>"
                                    class="w-full mt-1 border rounded p-2 dark:bg-gray-700 dark:text-gray-300" disabled>
                                <p class="text-gray-500 text-xs mt-1">Reserve amount is automatically updated based on transactions.</p>
                                <?php $__errorArgs = ['reserve'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Fixed Charge for Buy -->
                            <div>
                                <label class="block text-gray-700 dark:text-gray-300">Fixed Charge for Buy</label>
                                <input type="number" name="fixed_charge_for_buy" step="0.01"
                                    value="<?php echo e(old('fixed_charge_for_buy', $currency->fixed_charge_for_buy)); ?>"
                                    class="w-full mt-1 border rounded p-2 dark:bg-gray-700 dark:text-gray-300">
                                <?php $__errorArgs = ['fixed_charge_for_buy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Percentage Charge for Buy -->
                            <div>
                                <label class="block text-gray-700 dark:text-gray-300">Percentage Charge for Buy</label>
                                <input type="number" name="percent_charge_for_buy" step="0.01"
                                    value="<?php echo e(old('percent_charge_for_buy', $currency->percent_charge_for_buy)); ?>"
                                    class="w-full mt-1 border rounded p-2 dark:bg-gray-700 dark:text-gray-300">
                                <?php $__errorArgs = ['percent_charge_for_buy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Fixed Charge for Sell -->
                            <div>
                                <label class="block text-gray-700 dark:text-gray-300">Fixed Charge for Sell</label>
                                <input type="number" name="fixed_charge_for_sell" step="0.01"
                                    value="<?php echo e(old('fixed_charge_for_sell', $currency->fixed_charge_for_sell)); ?>"
                                    class="w-full mt-1 border rounded p-2 dark:bg-gray-700 dark:text-gray-300">
                                <?php $__errorArgs = ['fixed_charge_for_sell'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Percentage Charge for Sell -->
                            <div>
                                <label class="block text-gray-700 dark:text-gray-300">Percentage Charge for Sell</label>
                                <input type="number" name="percent_charge_for_sell" step="0.01"
                                    value="<?php echo e(old('percent_charge_for_sell', $currency->percent_charge_for_sell)); ?>"
                                    class="w-full mt-1 border rounded p-2 dark:bg-gray-700 dark:text-gray-300">
                                <?php $__errorArgs = ['percent_charge_for_sell'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Image Upload -->
                            <div class="mb-4">
                                <label class="block text-gray-700 dark:text-gray-300">Currency Image</label>
                                <input type="file" name="image"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>

                        <button type="submit"
                            class="px-4 py-2 bg-blue-500 text-white font-semibold rounded hover:bg-blue-600">Update Currency</button>
                        <a href="<?php echo e(route('currencies.index')); ?>"
                            class="px-4 py-2 bg-gray-500 text-white font-semibold rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-opacity-75 dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-500 transition duration-200">
                            Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Development\Laravel\ExchangePro\resources\views/currencies/edit.blade.php ENDPATH**/ ?>