<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-xl dark:text-white font-semibold">Edit Bank</h1>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="container mx-auto px-4 py-4">
                <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800 p-6">
                    <form action="<?php echo e(route('banks.update', $bank->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="grid gap-4 grid-cols-2">
                            <!-- Bank Name -->
                            <div class="mb-4">
                                <label for="name" class="block text-gray-700 dark:text-gray-300">Bank Name:</label>
                                <input type="text" name="name" id="name"
                                    value="<?php echo e(old('name', $bank->name)); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                            </div>

                            <!-- Beneficiary Name -->
                            <div class="mb-4">
                                <label for="beneficiary_name" class="block text-gray-700 dark:text-gray-300">Beneficiary Name:</label>
                                <input type="text" name="beneficiary_name" id="beneficiary_name"
                                    value="<?php echo e(old('beneficiary_name', $bank->beneficiary_name)); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                            </div>

                            <!-- Account Number -->
                            <div class="mb-4">
                                <label for="account_number" class="block text-gray-700 dark:text-gray-300">Account Number:</label>
                                <input type="text" name="account_number" id="account_number"
                                    value="<?php echo e(old('account_number', $bank->account_number)); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                            </div>

                            <!-- Account Type -->
                            <div class="mb-4">
                                <label for="account_type" class="block text-gray-700 dark:text-gray-300">Account Type:</label>
                                <select name="account_type" id="account_type" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                                    <option value="checking"
                                        <?php echo e(old('account_type', $bank->account_type) == 'checking' ? 'selected' : ''); ?>>
                                        Checking</option>
                                    <option value="savings"
                                        <?php echo e(old('account_type', $bank->account_type) == 'savings' ? 'selected' : ''); ?>>
                                        Savings</option>
                                </select>
                            </div>

                            <!-- Routing -->
                            <div class="mb-4">
                                <label for="routing" class="block text-gray-700 dark:text-gray-300">Routing:</label>
                                <input type="text" name="routing" id="routing"
                                    value="<?php echo e(old('routing', $bank->routing)); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                            </div>

                            <!-- Bank Address -->
                            <div class="mb-4">
                                <label for="bank_address" class="block text-gray-700 dark:text-gray-300">Bank Address:</label>
                                <input type="text" name="bank_address" id="bank_address"
                                    value="<?php echo e(old('bank_address', $bank->bank_address)); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                            </div>

                            <!-- NPSB Fee -->
                            <div class="mb-4">
                                <label for="npsb_fee" class="block text-gray-700 dark:text-gray-300">NPSB Fee (BDT):</label>
                                <input type="number" step="0.01" name="npsb_fee" id="npsb_fee"
                                    value="<?php echo e(old('npsb_fee', $bank->npsb_fee)); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                            </div>

                            <!-- EFT/BEFTN Fee -->
                            <div class="mb-4">
                                <label for="eft_beftn_fee" class="block text-gray-700 dark:text-gray-300">EFT/BEFTN Fee (BDT):</label>
                                <input type="number" step="0.01" name="eft_beftn_fee" id="eft_beftn_fee"
                                    value="<?php echo e(old('eft_beftn_fee', $bank->eft_beftn_fee)); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                            </div>

                            <!-- Logo (Image Upload) -->
                            <div class="mb-4">
                                <label for="logo" class="block text-gray-700 dark:text-gray-300">Bank Logo:</label>
                                <input type="file" name="logo" id="logo"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm" accept="image/*">
                                <?php if($bank->logo): ?>
                                    <div class="mt-2">
                                        <img src="<?php echo e(asset('storage/' . $bank->logo)); ?>" alt="Bank Logo"
                                            class="max-w-6 rounded-full">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit"
                            class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-500 transition duration-200">
                            Update Bank
                        </button>

                        <a href="<?php echo e(route('banks.index')); ?>"
                            class="px-4 py-2 ml-2 bg-gray-500 text-white font-semibold rounded-md hover:bg-gray-600 dark:bg-gray-600 dark:hover:bg-gray-700 transition duration-200">
                            Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Development\Laravel\ExchangePro\resources\views/banks/edit.blade.php ENDPATH**/ ?>