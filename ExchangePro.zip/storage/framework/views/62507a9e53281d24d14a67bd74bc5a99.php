<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-xl dark:text-white font-semibold">Exchange Details</h1>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="container mx-auto px-4 py-4">
                <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800 p-6">
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-6">Exchange ID: <?php echo e($exchange->id); ?></h2>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
                        <div class="flex items-center">
                            <span class="font-semibold text-gray-700 dark:text-gray-300 mr-2">Type:</span>
                            <span class="text-gray-800 dark:text-gray-200"><?php echo e(ucfirst($exchange->exchange_type)); ?></span>
                        </div>

                        <div class="flex items-center">
                            <span class="font-semibold text-gray-700 dark:text-gray-300 mr-2">Currency:</span>
                            <span class="text-gray-800 dark:text-gray-200"><?php echo e($exchange->currency->name); ?> (<?php echo e($exchange->currency->code); ?>)</span>
                        </div>

                        <div class="flex items-center">
                            <span class="font-semibold text-gray-700 dark:text-gray-300 mr-2">Quantity:</span>
                            <span class="text-gray-800 dark:text-gray-200"><?php echo e($exchange->quantity); ?></span>
                        </div>

                        <div class="flex items-center">
                            <span class="font-semibold text-gray-700 dark:text-gray-300 mr-2">Rate:</span>
                            <span class="text-gray-800 dark:text-gray-200"><?php echo e($exchange->rate); ?></span>
                        </div>

                        <div class="flex items-center">
                            <span class="font-semibold text-gray-700 dark:text-gray-300 mr-2">Status:</span>
                            <span class="px-2 py-1 rounded-full text-sm font-medium 
                                <?php echo e($exchange->status === 'approved' ? 'bg-green-200 text-green-700' : ($exchange->status === 'pending' ? 'bg-yellow-200 text-yellow-700' : 'bg-red-200 text-red-700')); ?>">
                                <?php echo e(ucfirst($exchange->status)); ?>

                            </span>
                        </div>
                    </div>

                    <div class="flex justify-end">
                        <a href="<?php echo e(route('exchanges.index')); ?>" 
                           class="px-4 py-2 bg-gray-500 text-white font-semibold rounded-md hover:bg-gray-600 dark:bg-gray-700 dark:hover:bg-gray-600 dark:text-gray-200 transition duration-200">
                            Back to All Exchanges
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Development\Laravel\ExchangePro\resources\views/exchanges/show.blade.php ENDPATH**/ ?>