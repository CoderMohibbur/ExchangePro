<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        All Exchanges
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-xl dark:text-white font-semibold">All Exchanges</h1>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="container mx-auto px-4 py-4">
                <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800">
                    <?php if (isset($component)) { $__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast-success','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast-success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06)): ?>
<?php $attributes = $__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06; ?>
<?php unset($__attributesOriginaleb6323af05d0beb14d8ecb5e3f5f4b06); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06)): ?>
<?php $component = $__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06; ?>
<?php unset($__componentOriginaleb6323af05d0beb14d8ecb5e3f5f4b06); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa)): ?>
<?php $attributes = $__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa; ?>
<?php unset($__attributesOriginal5456ec7d3b8c2e0d2da601d6e143d7aa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa)): ?>
<?php $component = $__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa; ?>
<?php unset($__componentOriginal5456ec7d3b8c2e0d2da601d6e143d7aa); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal56620e3087b695c518f488efcc0f195d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56620e3087b695c518f488efcc0f195d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast-warning','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56620e3087b695c518f488efcc0f195d)): ?>
<?php $attributes = $__attributesOriginal56620e3087b695c518f488efcc0f195d; ?>
<?php unset($__attributesOriginal56620e3087b695c518f488efcc0f195d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56620e3087b695c518f488efcc0f195d)): ?>
<?php $component = $__componentOriginal56620e3087b695c518f488efcc0f195d; ?>
<?php unset($__componentOriginal56620e3087b695c518f488efcc0f195d); ?>
<?php endif; ?>
                    <!-- Search Form -->
                    <div class="flex justify-between items-center p-4">
                        <form action="<?php echo e(route('exchanges.index')); ?>" method="GET" class="flex space-x-2">
                            <input type="text" name="search" placeholder="Search by user or exchange ID" 
                                   value="<?php echo e(request('search')); ?>" 
                                   class="w-full px-4 py-2 border rounded-md dark:bg-gray-700 dark:text-white dark:border-gray-600" />
                            <button type="submit" class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 transition">
                                Search
                            </button>
                        </form>
                        <a href="<?php echo e(route('exchanges.create')); ?>" 
                           class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 transition">
                           Add New Exchange
                        </a>
                    </div>

                    <!-- Exchanges Table -->
                    <div class="overflow-x-auto">
                        <table class="w-full min-w-max table-auto bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200">
                            <thead class="bg-gray-100 dark:bg-gray-700">
                                <tr>
                                    <th class="px-4 py-2 text-left font-semibold">Exchange ID</th>
                                    <th class="px-4 py-2 text-left font-semibold">User</th>
                                    <th class="px-4 py-2 text-left font-semibold">Received Method</th>
                                    <th class="px-4 py-2 text-left font-semibold">Received Amount</th>
                                    <th class="px-4 py-2 text-left font-semibold">Send Method</th>
                                    <th class="px-4 py-2 text-left font-semibold">Send Amount</th>
                                    <th class="px-4 py-2 text-center font-semibold">Status</th>
                                    <th class="px-4 py-2 text-center font-semibold">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $exchanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exchange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border-b border-gray-200 dark:border-gray-700">
                                        <td class="px-4 py-3">
                                            <span class="font-bold"><?php echo e($exchange->id); ?> | <?php echo e(ucfirst($exchange->exchange_type)); ?></span><br>
                                            <small class="text-gray-500 dark:text-gray-400"><?php echo e(\Carbon\Carbon::parse($exchange->date_time)->format('Y-m-d h:i A')); ?></small>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="block"><?php echo e($exchange->user->full_name ?? 'N/A'); ?></span>
                                            <small><a href="users/<?php echo e($exchange->user->id); ?>" class="text-blue-500 hover:underline"><?php echo e($exchange->user->username ?? 'N/A'); ?></a></small>
                                        </td>
                        
                                        <!-- Received Method (Dynamic) -->
                                        <td class="px-4 py-3">
                                            <?php if($exchange->exchange_type == 'buy'): ?>
                                                <span class="block"><?php echo e($exchange->currency->name ?? 'N/A'); ?></span>
                                                <small class="text-blue-500"><?php echo e($exchange->currency->code ?? ''); ?></small>
                                            <?php else: ?>
                                                <span class="block"><?php echo e($exchange->bank->name ?? 'N/A'); ?></span>
                                                <small class="text-blue-500">BDT</small>
                                            <?php endif; ?>
                                        </td>
                        
                                        <!-- Received Amount (Dynamic) -->
                                        <td class="px-4 py-3">
                                            <?php if($exchange->exchange_type == 'buy'): ?>
                                                <span class="block"><?php echo e(number_format($exchange->quantity, 2)); ?> <?php echo e($exchange->currency->code ?? ''); ?></span>
                                                <span><?php echo e(number_format($exchange->quantity, 2)); ?></span> x
                                                <span class="text-red-500"><?php echo e(number_format($exchange->rate ?? 0, 2)); ?></span> =
                                                <span><?php echo e(number_format($exchange->quantity * $exchange->rate, 2)); ?> BDT</span>
                                            <?php else: ?>
                                                <span class="block"><?php echo e(number_format($exchange->total_amount ?? 0, 2)); ?> BDT</span>
                                                <span><?php echo e(number_format($exchange->total_amount ?? 0, 2)); ?></span> +
                                                <span class="text-red-500"><?php echo e(number_format($exchange->send_fee ?? 0, 2)); ?></span> =
                                                <span><?php echo e(number_format(($exchange->total_amount ?? 0) + ($exchange->send_fee ?? 0), 2)); ?> BDT</span>
                                            <?php endif; ?>
                                        </td>
                        
                                        <!-- Send Method (Dynamic) -->
                                        <td class="px-4 py-3">
                                            <?php if($exchange->exchange_type == 'buy'): ?>
                                                <span class="block"><?php echo e($exchange->bank->name ?? 'N/A'); ?></span>
                                                <small class="text-blue-500">BDT</small>
                                            <?php else: ?>
                                                <span class="block"><?php echo e($exchange->currency->name ?? 'N/A'); ?></span>
                                                <small class="text-blue-500"><?php echo e($exchange->currency->code ?? ''); ?></small>
                                            <?php endif; ?>
                                        </td>
                        
                                        <!-- Send Amount (Dynamic) -->
                                        <td class="px-4 py-3">
                                            <?php if($exchange->exchange_type == 'buy'): ?>
                                            <span class="block"><?php echo e(number_format($exchange->total_amount ?? 0, 2)); ?> BDT</span>
                                            <span><?php echo e(number_format($exchange->total_amount ?? 0, 2)); ?></span> +
                                            <span class="text-red-500"><?php echo e(number_format($exchange->send_fee ?? 0, 2)); ?></span> =
                                            <span><?php echo e(number_format(($exchange->total_amount ?? 0) + ($exchange->send_fee ?? 0), 2)); ?> BDT</span>
                                            <?php else: ?>
                                                <span class="block"><?php echo e(number_format($exchange->quantity, 2)); ?> <?php echo e($exchange->currency->code ?? ''); ?></span>
                                                <span><?php echo e(number_format($exchange->quantity, 2)); ?></span> x
                                                <span class="text-red-500"><?php echo e(number_format($exchange->rate ?? 0, 2)); ?></span> =
                                                <span><?php echo e(number_format($exchange->quantity * $exchange->rate, 2)); ?> BDT</span>
                                            <?php endif; ?>
                                        </td>
                        
                                        <td class="px-4 py-3">
                                            <span class="px-2 py-1 rounded-full text-sm font-medium 
                                                <?php echo e($exchange->payment_status == 'Partial' ? 'bg-yellow-200 text-yellow-700 dark:bg-yellow-500 dark:text-yellow-100' : 
                                                ($exchange->payment_status == 'Paid' ? 'bg-green-200 text-green-700 dark:bg-green-500 dark:text-green-100' : 
                                                'bg-red-200 text-red-700 dark:bg-red-500 dark:text-red-100')); ?>">
                                                <?php echo e(ucfirst($exchange->payment_status)); ?>

                                            </span>
                                        </td>
                                        <td class="px-4 py-3 flex space-x-2">
                                            <a href="<?php echo e(route('exchanges.payment', $exchange->id)); ?>" 
                                                class="px-4 py-1 text-sm font-semibold text-green-500 border border-green-500 rounded hover:bg-green-500 hover:text-white dark:hover:bg-green-700 dark:hover:border-green-700 dark:border-green-500 dark:text-green-400 transition duration-200">
                                                <i class="las la-money-bill"></i> Pay
                                            </a>
                                            
                                            <form action="<?php echo e(route('exchanges.destroy', $exchange->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this exchange?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="px-4 py-1 text-sm font-semibold text-red-500 border border-red-500 rounded hover:bg-red-500 hover:text-white dark:hover:bg-red-700 dark:hover:border-red-700 dark:border-red-500 dark:text-red-400 transition duration-200">
                                                    <i class="las la-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="px-4 py-3 text-center text-gray-500 dark:text-gray-400">
                                            No exchanges found.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        
                        
                    </div>

                    <!-- Pagination -->
                    <div class="bg-gray-50 dark:bg-gray-900 p-4 rounded-b-lg">
                        <div class="flex items-center justify-between">
                            <p class="text-sm text-gray-600 dark:text-gray-400">
                                Showing <span class="font-semibold"><?php echo e($exchanges->firstItem()); ?></span> to <span class="font-semibold"><?php echo e($exchanges->lastItem()); ?></span> of <span class="font-semibold"><?php echo e($exchanges->total()); ?></span> results
                            </p>
                            <div class="flex">
                                <?php echo e($exchanges->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Development\Laravel\ExchangePro\resources\views/exchanges/index.blade.php ENDPATH**/ ?>