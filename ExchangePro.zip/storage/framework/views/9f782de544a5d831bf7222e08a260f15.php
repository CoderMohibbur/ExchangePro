<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Sell Dollar
     <?php $__env->endSlot(); ?>
    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <h1 class="text-xl dark:text-white font-semibold">Sell Dollar</h1>
        </div>
    </div>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="container mx-auto px-4 py-4">
                <div class="rounded-lg shadow-lg bg-white dark:bg-gray-800 p-6">
                    <?php if($errors->any()): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
                            <strong class="font-bold">Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('exchanges.sellDollarStore')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="grid gap-6 sm:grid-cols-2 sm:gap-4">

                            <!-- Exchange Type -->
                            <div class=" hidden">
                                <label for="exchange_type" class="block text-gray-700 dark:text-gray-300">Exchange
                                    Type:</label>
                                <select name="exchange_type" id="exchange_type"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                    required onchange="toggleUserFieldLabel(); toggleAmountFieldLabel();">
                                    <option value="sell">Sell</option>
                                    <option value="buy">Buy</option>
                                </select>
                            </div>

                            <!-- User Name (Dynamic Dropdown with Search) -->
                            <div>
                                <label id="user_field_label" for="user_search"
                                    class="block text-gray-700 dark:text-gray-300">User:</label>
                                <div class="relative">
                                    <input type="text" name="user_search" id="user_search"
                                        class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                        placeholder="Search for a user..." oninput="debounceSearchUsers()" required>
                                    <button type="button" id="defaultModalButton"
                                        data-modal-target="createUserdefaultModal"
                                        data-modal-toggle="createUserdefaultModal"
                                        class="text-white absolute end-2 bottom-1.5 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-1 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Add</button>
                                </div>
                                <div id="user_results"
                                    class="border border-gray-300 rounded-md bg-white dark:bg-gray-800 mt-2 hidden">
                                </div>
                                <input type="hidden" name="user_id" id="user_id">
                            </div>

                            <!-- Currency -->
                            <div>
                                <label for="currency_id"
                                    class="block text-gray-700 dark:text-gray-300">Currency:</label>
                                <select name="currency_id" id="currency_id"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                    required>
                                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($currency->id); ?>"><?php echo e($currency->name); ?>

                                            (<?php echo e($currency->code); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Quantity -->
                            <div>
                                <label for="quantity" class="block text-gray-700 dark:text-gray-300">Quantity:</label>
                                <input type="number" name="quantity" id="quantity"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                    step="0.01" required oninput="calculateTotal()">
                            </div>

                            <!-- Rate -->
                            <div>
                                <label for="rate" class="block text-gray-700 dark:text-gray-300">Rate:</label>
                                <input type="number" name="rate" id="rate"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                    step="0.01" required oninput="calculateTotal()">
                            </div>

                            <!-- Total Amount -->
                            <div>
                                <label for="total_amount" class="block text-gray-700 dark:text-gray-300">Total
                                    Amount:</label>
                                <input type="text" name="total_amount" id="total_amount"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                    readonly>
                            </div>

                            <!-- Paid Amount -->
                            <div>
                                <label id="paid_to_seller_bdt_label" for="paid_to_seller_bdt"
                                    class="block text-gray-700 dark:text-gray-300">Paid to
                                    Seller (BDT):</label>
                                <input type="number" name="paid_to_seller_bdt" id="paid_to_seller_bdt"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                    step="0.01" required oninput="updatePaymentStatus()">
                            </div>

                            <!-- Bank Selection -->
                            <div>
                                <label for="bank_id" class="block text-gray-700 dark:text-gray-300">Bank:</label>
                                <select name="bank_id" id="bank_id"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                    required>
                                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Bank Transaction Fees -->
                            <div id="bank_transaction_fees" class="hidden">
                                <label for="bank_transaction_fee" class="block text-gray-700 dark:text-gray-300">Bank
                                    Transaction Fee:</label>
                                <select name="bank_transaction_fee" id="bank_transaction_fee"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                                    <option value="">Select Bank Transaction Fee</option>
                                    <option value="npsb_fee">NPSB Fee</option>
                                    <option value="eft_beftn_fee">EFT/BEFTN Fee</option>
                                </select>
                            </div>

                            <!-- Currency Transaction Fees -->
                            <!-- Currency Transaction Fees -->
                            <div id="currency_transaction_fees" class="">
                                <label for="currency_transaction_fee_input"
                                    class="block text-gray-700 dark:text-gray-300">Currency Transaction Fee:</label>
                                <input list="currency_transaction_fee_list" id="currency_transaction_fee_input"
                                    name="currency_transaction_fee"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                    placeholder="Select or type fee">
                                <datalist id="currency_transaction_fee_list">
                                    <option value="No Fee"></option>
                                    <option value="Fixed Currency Fee"></option>
                                    <option value="Percentage Currency Fee"></option>
                                </datalist>
                            </div>

                            <!-- Exchange Status -->
                            <div>
                                <label for="exchange_status" class="block text-gray-700 dark:text-gray-300">Exchange
                                    Status:</label>
                                <select name="exchange_status" id="exchange_status"
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                    required>
                                    <option value="approved">Approved</option>
                                    <option value="pending">Pending</option>
                                    <option value="canceled">Canceled</option>
                                </select>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit"
                            class="inline-flex items-center px-5 py-2.5 mt-4 sm:mt-6 text-sm font-medium text-center text-white bg-primary-700 rounded-lg focus:ring-4 focus:ring-primary-200 dark:focus:ring-primary-900 hover:bg-primary-800">
                            Create Exchange
                        </button>
                        <a href="<?php echo e(route('exchanges.index')); ?>"
                            class="px-4 py-2 bg-gray-500 text-white font-semibold rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-opacity-75 dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-500 transition duration-200">
                            Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Add user Modal -->
    <div id="createUserdefaultModal" tabindex="-1" aria-hidden="true"
        class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-modal md:h-full">
        <div class="relative p-4 w-full max-w-2xl h-full md:h-auto">
            <!-- Modal content -->
            <div class="relative p-4 bg-white rounded-lg shadow dark:bg-gray-800 sm:p-5">
                <!-- Modal header -->
                <div
                    class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5 dark:border-gray-600">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        Add New User
                    </h3>
                    <button type="button"
                        class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white"
                        data-modal-toggle="createUserdefaultModal">
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <form id="createUserForm">
                    <?php echo csrf_field(); ?>
                    <div class=" grid grid-cols-2 gap-4">
                        <!-- First Name -->
                        
                        <div>
                            <label for="first_name" class="block text-gray-700 dark:text-gray-300">Full Name:</label>
                            <input type="text" name="first_name" id="first_name"
                                class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm"
                                required>
                        </div>

                        

                        <!-- Last Name -->
                        

                        

                        <!-- Username -->
                        <div>
                            <label for="username" class="block text-gray-700 dark:text-gray-300">Username:</label>
                            <input type="text" name="username" id="username"
                                class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                        </div>

                        <!-- Phone Number -->
                        <div>
                            <label for="phone_number" class="block text-gray-700 dark:text-gray-300">Phone
                                Number:</label>
                            <input type="text" name="phone_number" id="phone_number"
                                class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                        </div>


                        <!-- Role -->
                        <div>
                            <label for="role_id" class="block text-gray-700 dark:text-gray-300">Role:</label>
                            <select name="role_id" id="role_id"
                                class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- User Type -->
                        <div>
                            <label for="user_type_id" class="block text-gray-700 dark:text-gray-300">User
                                Type:</label>
                            <select name="user_type_id" id="user_type_id"
                                class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                                <?php $__currentLoopData = $userTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($userType->id); ?>"><?php echo e($userType->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>



                        <!-- Password -->
                        

                        <!-- Confirm Password -->
                        

                        <!-- Active Status -->
                        <div class="mb-4">
                            <label for="active_status" class="block text-gray-700 dark:text-gray-300">Status:</label>
                            <select name="active_status" id="active_status"
                                class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>

                        <!-- Allow Login Checkbox -->
                        
                    </div>
                    <!-- Submit Button -->
                    <button type="submit"
                        class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 transition duration-200">
                        Create User
                    </button>

                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript for dynamic field label and search functionality -->

    <script>
        document.getElementById('createUserForm').addEventListener('submit', function(e) {
            e.preventDefault(); // Prevent default form submission

            let formData = new FormData(this); // Get form data

            // Make the AJAX request using fetch
            fetch("<?php echo e(route('users.storesave')); ?>", {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Close the modal
                        document.querySelector('[data-modal-toggle="createUserdefaultModal"]')
                            .click(); // Manually trigger closing

                        // Select the newly created user in the dropdown
                        // let userDropdown = document.getElementById('user_id');
                        // let option = document.createElement('option');
                        // option.value = data.data.id;
                        // option.text = `${data.data.first_name} ${data.data.last_name}`;
                        // userDropdown.appendChild(option);
                        // userDropdown.value = data.data.id; // Select the newly created user

                        // Set the first_name in the input field
                        document.getElementById('user_search').value = data.data.first_name;

                        // Set the user_id in the hidden field
                        document.getElementById('user_id').value = data.data.id;

                        // Optionally, display a success message
                        alert('User created successfully');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function(event) {
            document.getElementById('defaultModalButton').click();
        });
    </script>
    <script>
        function toggleUserFieldLabel() {
            const exchangeType = document.getElementById('exchange_type').value;
            const userFieldLabel = document.getElementById('user_field_label');
            userFieldLabel.innerText = exchangeType === 'buy' ? 'Seller Name:' : 'Buyer Name:';
        }

        function toggleAmountFieldLabel() {
            const exchangeType = document.getElementById('exchange_type').value;
            const amountLabel = document.getElementById('paid_to_seller_bdt_label'); // Get the label by ID
            amountLabel.innerText = exchangeType === 'buy' ? 'Paid To Seller (BDT):' : 'Received From Buyer (BDT):';
        }

        function calculateTotal() {
            const quantity = parseFloat(document.getElementById('quantity').value) || 0;
            const rate = parseFloat(document.getElementById('rate').value) || 0;
            const totalAmount = quantity * rate;
            document.getElementById('total_amount').value = totalAmount.toFixed(2);
            document.getElementById('paid_to_seller_bdt').value = totalAmount.toFixed(2);
        }

        function updatePaymentStatus() {
            const totalAmount = parseFloat(document.getElementById('total_amount').value) || 0;
            const paidAmount = parseFloat(document.getElementById('paid_to_seller_bdt').value) || 0;

            if (paidAmount >= totalAmount) {
                document.getElementById('status').value = 'Paid';
            } else if (paidAmount > 0) {
                document.getElementById('status').value = 'Partial';
            } else {
                document.getElementById('status').value = 'Due';
            }
        }

        let debounceTimeout;

        function debounceSearchUsers() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(searchUsers, 300);
        }

        function searchUsers() {
            const query = document.getElementById('user_search').value;
            if (query.length < 1) {
                document.getElementById('user_results').classList.add('hidden');
                return;
            }

            fetch(`/api/users/search?q=${query}`)
                .then(response => response.json())
                .then(data => {
                    const resultsContainer = document.getElementById('user_results');
                    resultsContainer.innerHTML = '';
                    resultsContainer.classList.toggle('hidden', data.length === 0);

                    data.forEach(user => {
                        const item = document.createElement('div');
                        item.classList.add('p-2', 'text-gray-700', 'dark:text-white', 'cursor-pointer',
                            'hover:bg-gray-200', 'dark:hover:bg-gray-700');
                        item.innerText = `${user.first_name} (@${user.username})`;
                        item.onclick = () => selectUser(user);
                        resultsContainer.appendChild(item);
                    });
                })
                .catch(error => {
                    console.error('Error fetching users:', error);
                    document.getElementById('user_results').classList.add('hidden');
                });
        }

        function selectUser(user) {
            document.getElementById('user_search').value = `${user.first_name} (@${user.username})`;
            document.getElementById('user_id').value = user.id;
            document.getElementById('user_results').classList.add('hidden');
        }

        toggleUserFieldLabel();
        calculateTotal();
        updatePaymentStatus();
        toggleAmountFieldLabel();
    </script>
    <script>
        document.getElementById('bank_id').addEventListener('change', function() {
            const bankId = this.value;
            if (bankId) {
                fetch(`/get-bank-fees/${bankId}`)
                    .then(response => response.json())
                    .then(data => {
                        const bankFeesDropdown = document.getElementById('bank_transaction_fee');
                        bankFeesDropdown.innerHTML = `
                            <option value="0">No Fee</option>
                            <option value="${data.npsb_fee}">NPSB Fee (${data.npsb_fee})</option>
                            <option value="${data.eft_beftn_fee}">EFT/BEFTN Fee (${data.eft_beftn_fee})</option>
                        `;
                    });
            }
        });

        document.getElementById('currency_id').addEventListener('change', function() {
            const currencyId = this.value;
            if (currencyId) {
                fetch(`/get-currency-fees/${currencyId}`)
                    .then(response => response.json())
                    .then(data => {
                        const currencyFeesList = document.getElementById('currency_transaction_fee_list');
                        const currencyFeesInput = document.getElementById('currency_transaction_fee_input');

                        // Populate datalist options dynamically using the preferred structure
                        currencyFeesList.innerHTML = `
                            <option value="0">No Fee</option>
                            <option value="${data.percent_charge_for_sell}">Percentage Currency Fee (${data.percent_charge_for_sell}%)</option>
                            <option value="${data.fixed_charge_for_sell}">Fixed Currency Fee (${data.fixed_charge_for_sell})</option>
                        `;

                        // Set "No Fee" as the default value in the input field
                        currencyFeesInput.value = "0";
                    });
            }
        });


    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const bankId = document.getElementById('bank_id').value;
            const currencyId = document.getElementById('currency_id').value;
            if (bankId) document.getElementById('bank_id').dispatchEvent(new Event('change'));
            if (currencyId) document.getElementById('currency_id').dispatchEvent(new Event('change'));
        });

        document.getElementById('exchange_type').addEventListener('change', function() {
            const exchangeType = this.value;
            const bankTransactionFeeField = document.getElementById('bank_transaction_fee');

            if (exchangeType === 'sell') {
                bankTransactionFeeField.innerHTML = `
            <option value="0" selected>No Fee</option>
        `;
                bankTransactionFeeField.value = 0;
                bankTransactionFeeField.setAttribute('disabled', true); // Disable the field
            } else {
                bankTransactionFeeField.removeAttribute('disabled'); // Enable the field
                const bankId = document.getElementById('bank_id').value; // Get selected bank
                if (bankId) {
                    fetch(`/get-bank-fees/${bankId}`)
                        .then(response => response.json())
                        .then(data => {
                            bankTransactionFeeField.innerHTML = `
                        <option value="0">No Fee</option>
                        <option value="${data.npsb_fee}">NPSB Fee (${data.npsb_fee})</option>
                        <option value="${data.eft_beftn_fee}">EFT/BEFTN Fee (${data.eft_beftn_fee})</option>
                    `;
                            bankTransactionFeeField.value = data.npsb_fee; // Default to NPSB Fee
                        });
                }
            }
        });
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            const exchangeType = document.getElementById('exchange_type').value;
            const bankTransactionFeeField = document.getElementById('bank_transaction_fee');

            if (exchangeType === 'sell') {
                bankTransactionFeeField.value = 0;
                bankTransactionFeeField.setAttribute('disabled', true);
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Development\Laravel\ExchangePro\resources\views/exchanges/sell.blade.php ENDPATH**/ ?>