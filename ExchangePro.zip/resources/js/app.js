import './bootstrap';

import Alpine from 'alpinejs';
import 'flowbite'; // Import Flowbite
window.Alpine = Alpine;

Alpine.start();