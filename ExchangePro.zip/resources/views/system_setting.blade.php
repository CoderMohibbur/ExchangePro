<x-app-layout>
    <x-slot name="header">
        <h1 class=" text-xl dark:text-white font-semibold">System Settings

        </h1>
    </x-slot>

    <h1>System Settings
    </h1>

</x-app-layout>
